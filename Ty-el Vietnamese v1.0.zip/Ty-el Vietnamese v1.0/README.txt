[Tiếng Việt ở dưới \/]
[English-US]
Welcome to @MC_VN's ty-el Vietnamese.

Pack updates very regularly, so don't forget to update this pack to avoid some weird bugs/wrong translations later.

[Tiếng Việt-Việt Nam]
Chào mừng đến với ty-el Vietnamese của @MC_VN

Gói cập nhật rất thường xuyên, vì vậy đừng quên cập nhật gói này để tránh một số lỗi kỳ lạ/bản dịch sai sau này.
_________________________________________________
BUNDLED IN THIS PACK
- MinecraftSeven & MinecraftSeven (Smooth Variant):
    Originally created by @MC_VN, modified by @MC_VN
- Unifont:
    Created by @MC_VN, based on the Unicode font part that can be found in Minecraft game data (which is Unifont).
- Noto Sans (/font/NotoSans/NotoSans-Regular.ttf):
    Noto Sans is licensed under the SIL Open Font License, Version 1.1. The copy of this license can be found in /font/NotoSans/LICENSE.txt.
_________________________________________________
Original translations and texts are from ©Microsoft and ©Mojang, AB. All rights reserved!

;-;